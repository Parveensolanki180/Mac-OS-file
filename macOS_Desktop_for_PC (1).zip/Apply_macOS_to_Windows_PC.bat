@echo off
title macOS Desktop Environment Launcher for Windows PC
color 0B
echo ================================================================
echo   Applying macOS Tahoe / Sequoia Desktop Experience for Windows
echo ================================================================
echo.
set "HTML_FILE=%~dp0macOS_Desktop_for_PC.html"
if not exist "%HTML_FILE%" (
  echo Ensure macOS_Desktop_for_PC.html is in the same folder as this launcher.
)
echo Launching borderless fullscreen macOS Desktop via Microsoft Edge / Chrome App Mode...
start "" msedge --app="file:///%HTML_FILE%" --start-fullscreen
exit